function time() {
  let a=new Date()
  let h=a.getHours()
  let m=a.getMinutes()
  let s=a.getSeconds()
  let d=a.getDate()
  let final= h+':'+m+':'+s
  return final
  
}



let z=document.getElementById("time").innerHTML= time()
